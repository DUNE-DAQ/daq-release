
void ups_append_OS(char *flavor);
void ups_append_MACHINE(char *buf);
void ups_append_release(char *flavor);
void ups_make_default_quals_optional();
char *ups_get_default_quals();
char *ups_get_default_host();
char *ups_get_default_B();
int ups_64bit_check();
