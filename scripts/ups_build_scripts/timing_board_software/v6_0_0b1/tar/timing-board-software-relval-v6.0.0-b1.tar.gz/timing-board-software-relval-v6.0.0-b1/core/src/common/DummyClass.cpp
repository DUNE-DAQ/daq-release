#include "pdt/DummyClass.hpp"

namespace pdt {

DummyClass::DummyClass() {

}

DummyClass::~DummyClass() {
	
}

} // namespace pdt