#ifndef __PDT_CORE_DUMMYCLASS_HPP__
#define __PDT_CORE_DUMMYCLASS_HPP__

namespace pdt {
class DummyClass {

  public:
    DummyClass();
    ~DummyClass();
};

} // namespace pdt

#endif /* __PDT_CORE_DUMMYCLASS_HPP__ */