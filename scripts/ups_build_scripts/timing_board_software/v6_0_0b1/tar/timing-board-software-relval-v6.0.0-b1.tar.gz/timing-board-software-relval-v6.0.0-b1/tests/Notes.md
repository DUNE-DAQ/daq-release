### Version v3c

```
--(ouroboros)--> ./board_setup.py DUNE_FMC_SLAVE_TUN
20-07-17 12:17:09.547660 [7fd706f4c740] WARNING - Class "SI5344Node" is unknown to the NodeTreeBuilder class factory. A plain node will be returned instead.
20-07-17 12:17:09.547711 [7fd706f4c740] WARNING - No class types have been defined
DUNE_FMC_SLAVE_TUN
0x7
I2c enable lines: [127]
Unique ID PROM / board rev: 0xd880395e5069 1
  CLOCK EPROM:
          0x44 0x53
Si5344 Set Reg Page: 0
        Parsing file SI5344/PDTS0000.txt
           445 elements
        Write configuration:
Freq: 0 1 249.994138716
Freq: 1 1 249.993900297
DUNE_FMC_SLAVE_TUN
0x1f
```